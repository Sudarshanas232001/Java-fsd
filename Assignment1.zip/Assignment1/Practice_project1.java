package com.learning.core.Phase1;

import java.util.Scanner;

public class Practice_project1 {
    public static void main(String[] args) {
        // Implicit type casting (widening conversion)
    	Scanner sc = new Scanner(System.in);
        int intValue = sc.nextInt();
        double doubleValue = intValue; // int to double (implicit casting)
        System.out.println("Implicit casting: int to double");
        System.out.println("int value: " + intValue);
        System.out.println("double value: " + doubleValue);

        // Explicit type casting (narrowing conversion)
        double bigDoubleValue = sc.nextDouble();
        int smallIntValue = (int) bigDoubleValue; // double to int (explicit casting)
        System.out.println("\nExplicit casting: double to int");
        System.out.println("double value: " + bigDoubleValue);
        System.out.println("int value: " + smallIntValue);
        sc.close();
    }

}
