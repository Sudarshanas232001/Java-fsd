package com.learning.core.Phase1;

public class Practice_project8 {

    public static void main(String[] args) {
        demonstrateStringMethods();
        demonstrateStringBufferMethods();
        demonstrateStringBuilderMethods();
        convertStringToStringBufferAndStringBuilder();
    }

    public static void demonstrateStringMethods() {
        System.out.println("Methods of Strings");

        // length
        String sl = "Hello World";
        System.out.println("Length: " + sl.length());

        // substring
        String sub = "Welcome";
        System.out.println("Substring: " + sub.substring(2));

        // compareTo
        String s1 = "Hello";
        String s2 = "Heldo";
        System.out.println("Comparison: " + s1.compareTo(s2));

        // isEmpty
        String s4 = "";
        System.out.println("Is Empty: " + s4.isEmpty());

        // toLowerCase
        String s5 = "Hello";
        System.out.println("Lowercase: " + s5.toLowerCase());

        // replace
        String s6 = "Heldo";
        String replace = s6.replace('d', 'l');
        System.out.println("Replace: " + replace);

        // equals
        String x = "Welcome to Java";
        String y = "WeLcOmE tO JaVa";
        System.out.println("Equals: " + x.equalsIgnoreCase(y));
        System.out.println();
    }

    public static void demonstrateStringBufferMethods() {
        System.out.println("Creating StringBuffer");

        // Creating StringBuffer and append method
        StringBuffer sb = new StringBuffer("Welcome to Java!");
        sb.append(" Enjoy your learning");
        System.out.println(sb);

        // insert method
        sb.insert(0, 'w');
        System.out.println(sb);

        // replace method
        sb.replace(0, 2, "hEl");
        System.out.println(sb);

        // delete method
        sb.delete(0, 1);
        System.out.println(sb);
        System.out.println();
    }

    public static void demonstrateStringBuilderMethods() {
        System.out.println("Creating StringBuilder");

        // Creating StringBuilder and append method
        StringBuilder sb = new StringBuilder("Happy");
        sb.append(" Learning");
        System.out.println(sb);

        // delete method
        System.out.println(sb.delete(0, 1));

        // insert method
        System.out.println(sb.insert(1, "Welcome"));

        // reverse method
        System.out.println(sb.reverse());
        System.out.println();
    }

    public static void convertStringToStringBufferAndStringBuilder() {
        System.out.println("Conversion of Strings to StringBuffer and StringBuilder");

        String str = "Hello";

        // Conversion from String to StringBuffer
        StringBuffer sb = new StringBuffer(str);
        sb.reverse();
        System.out.println("String to StringBuffer: " + sb);

        // Conversion from String to StringBuilder
        StringBuilder sbl = new StringBuilder(str);
        sbl.append(" world");
        System.out.println("String to StringBuilder: " + sbl);
    }
}
