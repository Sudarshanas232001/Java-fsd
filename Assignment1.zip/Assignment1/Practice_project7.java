package com.learning.core.Phase1;

//Regular Inner Class
class OuterClass {
 private String msg = "Welcome to Java";

 class Inner {
     void hello() {
         System.out.println(msg + ", Let us start learning Inner Classes");
     }
 }

 void useInnerClass() {
     Inner inner = new Inner();
     inner.hello();
 }
}

//Inner Class Inside Method
class OuterClass2 {
 private String msg = "Inner Classes";

 void display() {
     class Inner {
         void msg() {
             System.out.println(msg);
         }
     }

     Inner inner = new Inner();
     inner.msg();
 }
}

//Anonymous Inner Class
abstract class AnonymousInnerClass {
 public abstract void display();
}

public class Practice_project7 {
 public static void main(String[] args) {
     // Regular Inner Class Example
     OuterClass outer = new OuterClass();
     outer.useInnerClass();

     // Inner Class Inside Method Example
     OuterClass2 outer2 = new OuterClass2();
     outer2.display();

     // Anonymous Inner Class Example
     AnonymousInnerClass inner = new AnonymousInnerClass() {
         public void display() {
             System.out.println("Anonymous Inner Class");
         }
     };
     inner.display();
 }
}
