package com.example;

import org.hibernate.Session;

public class App {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

        Employee emp = new Employee("John", "Doe");
        session.save(emp);

        session.getTransaction().commit();
        session.close();

        System.out.println("Employee saved successfully!");
    }
}
