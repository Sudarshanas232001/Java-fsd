public class Employee {
    private int id;
    private String name;
    private List<PhoneNumber> phoneNumbers; // List example
    private Set<String> skills; // Set example
    private Map<String, String> certifications; // Map example

    // Constructors, getters, and setters
    public Employee() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<PhoneNumber> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Set<String> getSkills() {
        return skills;
    }

    public void setSkills(Set<String> skills) {
        this.skills = skills;
    }

    public Map<String, String> getCertifications() {
        return certifications;
    }

    public void setCertifications(Map<String, String> certifications) {
        this.certifications = certifications;
    }
}
