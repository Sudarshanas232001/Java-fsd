import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Author author = new Author();
        author.setName("J.K. Rowling");
        Book book1 = new Book();
        book1.setTitle("Harry Potter and the Sorcerer's Stone");
        book1.setAuthor(author);
        session.save(author);
        session.save(book1);

        session.getTransaction().commit();

        // Demonstrate lazy loading
        Query<Author> query = session.createQuery("from Author", Author.class);
        Author fetchedAuthor = query.uniqueResult();
        System.out.println("Author Name: " + fetchedAuthor.getName());
        // Access books (lazy-loaded)
        fetchedAuthor.getBooks().forEach(book -> System.out.println("Book Title: " + book.getTitle()));

        session.close();
        sessionFactory.close();
    }
}
