import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        
        // Example operation
        // Assuming you have a mapped entity `User`
        User user = new User();
        user.setName("John Doe");
        session.save(user);
        
        transaction.commit();
        session.close();
        sessionFactory.close();
    }
}
