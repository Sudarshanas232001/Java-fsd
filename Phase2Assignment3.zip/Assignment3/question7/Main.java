import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Employee employee = new Employee();
        Name name = new Name();
        name.setFirstName("John");
        name.setLastName("Doe");
        employee.setName(name);

        session.save(employee);
        session.getTransaction().commit();

        // Fetch and print the employee data
        Employee emp = session.get(Employee.class, employee.getId());
        System.out.println("Employee Name: " + emp.getName().getFirstName() + " " + emp.getName().getLastName());

        session.close();
        sessionFactory.close();
    }
}
