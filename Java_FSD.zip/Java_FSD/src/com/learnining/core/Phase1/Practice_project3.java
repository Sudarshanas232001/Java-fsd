package com.learnining.core.Phase1;

import java.util.Scanner;

/*public class Practice_project3 {

    // Method to verify implementation
    public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    // Method to verify different ways of calling a method
    public static void printMessage(String message) {
        System.out.println(message);
    }

    public static void main(String[] args) {
        // Verifying isPrime method implementation
        System.out.println("Verifying isPrime method implementation:");
        System.out.println("Is 5 prime? " + isPrime(5)); // Should print true
        System.out.println("Is 10 prime? " + isPrime(10)); // Should print false

        // Verifying different ways of calling a method
        System.out.println("\nVerifying different ways of calling a method:");
        printMessage("Hello, World!"); // Should print "Hello, World!"
        String message = "Goodbye!";
        printMessage(message); // Should print "Goodbye!"

        // Additional verification can be added as needed
    }
}*/


public class Practice_project3 {

    // Method overloading - same method name but different parameter types
    public static void display(int num) {
        System.out.println("Integer number: " + num);
    }

    public static void display(double num) {
        System.out.println("Double number: " + num);
    }

    // Method to demonstrate call-by-value
    public static void modifyValue(int value) {
        System.out.println("Inside modifyValue method - Before modification: " + value);
        value += 10;
        System.out.println("Inside modifyValue method - After modification: " + value);
    }

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
        int intValue = sc.nextInt();
        double doubleValue = sc.nextDouble();

        // Method overloading demonstration
        display(intValue); // Calls the display method with int parameter
        display(doubleValue); // Calls the display method with double parameter

        System.out.println("\nOriginal value of intValue: " + intValue);
        // Call-by-value demonstration
        modifyValue(intValue); // Passes intValue by value
        System.out.println("Value of intValue after modifyValue method call: " + intValue);
        sc.close();
    }
}
