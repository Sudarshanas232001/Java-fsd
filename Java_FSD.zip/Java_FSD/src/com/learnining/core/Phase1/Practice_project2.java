package com.learnining.core.Phase1;

//import java.lang.reflect.Method;

//Define a class with different access modifiers
public class Practice_project2 {
public int publicVar = 10;
protected int protectedVar = 20;
int defaultVar = 30; // default access modifier
private int privateVar = 40;

// Methods with different access modifiers
public void publicMethod() {
   System.out.println("Public method");
}

protected void protectedMethod() {
   System.out.println("Protected method");
}

void defaultMethod() {
   System.out.println("Default method");
}

private void privateMethod() {
   System.out.println("Private method");
}

// Main method to test access modifiers
public static void main(String[] args) {
   Practice_project2 obj = new Practice_project2();

   // Accessing variables
   System.out.println("Public variable: " + obj.publicVar);
   System.out.println("Protected variable: " + obj.protectedVar);
   System.out.println("Default variable: " + obj.defaultVar);
   System.out.println("Private variable: " + obj.privateVar); // Error: privateVar has private access in MyClass

   // Accessing methods
   obj.publicMethod();
   obj.protectedMethod();
   obj.defaultMethod();
   obj.privateMethod(); // Error: privateMethod() has private access in MyClass
}


 /* public static void main(String[] args) throws Exception {
      MyClass obj = new MyClass();

      // Using reflection to access private method
      Method privateMethod = MyClass.class.getDeclaredMethod("privateMethod");
      privateMethod.setAccessible(true);
      privateMethod.invoke(obj);
  }*/
}