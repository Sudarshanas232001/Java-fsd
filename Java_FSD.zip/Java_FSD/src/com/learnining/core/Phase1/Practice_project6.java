package com.learnining.core.Phase1;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Hashtable;

public class Practice_project6 {
    public static void main(String[] args) {
        // Create map implementations to verify
        Map<String, Integer> hashMap = new HashMap<>();
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        Map<String, Integer> treeMap = new TreeMap<>();
        Map<String, Integer> hashTable = new Hashtable<>();

        // Add elements to the maps
        hashMap.put("Alice", 25);
        hashMap.put("Bob", 30);
        hashMap.put("Charlie", 35);

        linkedHashMap.put("Alice", 25);
        linkedHashMap.put("Bob", 30);
        linkedHashMap.put("Charlie", 35);

        treeMap.put("Alice", 25);
        treeMap.put("Bob", 30);
        treeMap.put("Charlie", 35);

        hashTable.put("Alice", 25);
        hashTable.put("Bob", 30);
        hashTable.put("Charlie", 35);

        // Print elements of each map to verify the insertion order
        System.out.println("The elements of HashMap are ");
        printMap(hashMap);

        System.out.println("\nThe elements of LinkedHashMap are");
        printMap(linkedHashMap);

        System.out.println("\nThe elements of TreeMap are");
        printMap(treeMap);

        System.out.println("\nThe elements of Hashtable are");
        printMap(hashTable);
    }

    // Method to print elements of a map
    private static void printMap(Map<String, Integer> map) {
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getValue() + " " +  entry.getKey());
        }
    }
}

