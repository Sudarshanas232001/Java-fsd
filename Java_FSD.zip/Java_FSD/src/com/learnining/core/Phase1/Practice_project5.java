package com.learnining.core.Phase1;

import java.util.*;

public class Practice_project5 {
    public static void main(String[] args) {
        // ArrayList implementation
        List<String> arrayList = new ArrayList<>();
        arrayList.add("Java");
        arrayList.add("Python");
        arrayList.add("C++");

        // Vector implementation
        List<String> vector = new Vector<>();
        vector.add("HTML");
        vector.add("CSS");
        vector.add("JavaScript");

        // LinkedList implementation
        List<String> linkedList = new LinkedList<>();
        linkedList.add("Ruby");
        linkedList.add("PHP");
        linkedList.add("Swift");

        // HashSet implementation
        Set<Integer> hashSet = new HashSet<>();
        hashSet.add(10);
        hashSet.add(20);
        hashSet.add(30);

        // LinkedHashSet implementation
        Set<Integer> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add(100);
        linkedHashSet.add(200);
        linkedHashSet.add(300);

        // Print elements of each collection
        System.out.println("ArrayList elements:\n" + arrayList);
        System.out.println("Vector elements:\n" + vector);
        System.out.println("LinkedList elements:\n" + linkedList);
        System.out.println("HashSet elements:\n" + hashSet);
        System.out.println("LinkedHashSet elements:\n" + linkedHashSet);
    }
}
