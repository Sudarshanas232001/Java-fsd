package com.learnining.core.Phase1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practice_project_10 {
    public static void main(String[] args) {
        // Define an array of regex patterns to test
        String[] regexPatterns = {
                "\\d+",                 // Matches one or more digits
                "\\w+",                 // Matches one or more word characters
                "[a-zA-Z]+",            // Matches one or more alphabetic characters
                "\\b\\d{3}-\\d{2}-\\d{4}\\b" // Matches social security number pattern (###-##-####)
        };

        // Define an array of input strings to test against the regex patterns
        String[] inputStrings = {
                "12345",                // Should match "\\d+" pattern
                "Hello123",             // Should match "\\w+" pattern
                "java Programming",     // Should match "[a-zA-Z]+" pattern (case insensitive)
                "123-45-6789",          // Should match social security number pattern
                "abc-def-ghi"           // Should not match any pattern
        };

        // Loop through each regex pattern and test against input strings
        for (String regex : regexPatterns) {
            Pattern pattern = Pattern.compile(regex);

            System.out.println("Testing pattern: " + regex);
            for (String input : inputStrings) {
                Matcher matcher = pattern.matcher(input);
                boolean isMatch = matcher.find(); // Use find() for partial matches

                if (isMatch) {
                    System.out.println("Pattern matched for input '" + input + "'");
                } else {
                    System.out.println("Pattern not matched for input '" + input + "'");
                }
            }
            System.out.println(); // Empty line for readability
        }
    }
}
