package com.learnining.core.Phase1;

public class Practice_project4 {
    private int value;

    // Default constructor
    public Practice_project4() {
        this.value = 0;
    }

    // Parameterized constructor
    public Practice_project4(int value) {
        this.value = value;
    }

    // Constructor overloading
    public Practice_project4(String strValue) {
        this.value = Integer.parseInt(strValue);
    }

    public int getValue() {
        return value;
    }

    public static void main(String[] args) {
        // Testing default constructor
    	Practice_project4 obj1 = new Practice_project4();
        System.out.println("Default Constructor - Value: " + obj1.getValue());

        // Testing parameterized constructor
        Practice_project4 obj2 = new Practice_project4(100);
        System.out.println("Parameterized Constructor - Value: " + obj2.getValue());

        // Testing constructor overloading
        Practice_project4 obj3 = new Practice_project4("200");
        System.out.println("Constructor Overloading - Value: " + obj3.getValue());
    }
}
