package com.learnining.core.Phase1;

import java.util.Arrays;

public class Practice_project9 {
    public static void main(String[] args) {
        // Creating an array
        int[] numbers = {5, 10, 15, 20, 25};

        // Verifying array length
        int length = numbers.length;
        System.out.println("Array length: " + length);

        // Accessing elements in the array
        int firstElement = numbers[0];
        int lastElement = numbers[length - 1];
        System.out.println("First element: " + firstElement);
        System.out.println("Last element: " + lastElement);

        // Modifying an element in the array
        numbers[2] = 30;
        System.out.println("Modified array: " + Arrays.toString(numbers));

        // Iterating through the array
        System.out.print("Array elements:");
        for (int num : numbers) {
            System.out.print(" " + num);
        }
        System.out.println();

        // Sorting the array
        Arrays.sort(numbers);
        System.out.println("Sorted array: " + Arrays.toString(numbers));

        // Searching for an element in the array
        int searchElement = 15;
        int index = Arrays.binarySearch(numbers, searchElement);
        if (index >= 0) {
            System.out.println(searchElement + " found at index " + index);
        } else {
            System.out.println(searchElement + " not found in the array");
        }

        // Copying an array
        int[] copyOfNumbers = Arrays.copyOf(numbers, numbers.length);
        System.out.println("Copied array: " + Arrays.toString(copyOfNumbers));
    }
}
