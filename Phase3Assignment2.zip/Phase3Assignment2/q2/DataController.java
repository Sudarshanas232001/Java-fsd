import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
public class DataController {

    private final RestClientService restClientService;

    @Autowired
    public DataController(RestClientService restClientService) {
        this.restClientService = restClientService;
    }

    @GetMapping("/fetch-data")
    public String fetchData(@RequestParam String url) {
        return restClientService.getDataFromService(url);
    }
}
