package com.learning.core.Phase1Assignment2;

//Write a program in Java to demonstrate the uses of classes, objects, and the object-oriented pillars in Java

class Animal {

  // Encapsulation - private attribute with public getter
  private String name;

  public String getName() {
      return name;
  }

  // Abstraction - constructor hides internal object creation logic
  public Animal(String name) {
      this.name = name;
  }

  // Polymorphism - Method with same name but different behavior based on subclass
  public void makeSound() {
      System.out.println("Generic animal sound");
  }
}

class Dog extends Animal {

  // Inheritance - Dog inherits attributes and methods from Animal
  public Dog(String name) {
      super(name); // Call parent class constructor
  }

  // Polymorphism - Override makeSound with dog-specific behavior
  @Override
  public void makeSound() {
      System.out.println("Bow!");
  }
}

public class P08 {

  public static void main(String[] args) {
      // Class - Animal blueprint for creating objects
      Animal animal = new Animal("dog"); // Object creation - instance of Animal
      System.out.println(animal.getName()); // Access attribute using public getter

      Dog dog = new Dog("Charlie"); // Object creation - instance of Dog (subclass of Animal)
      System.out.println(dog.getName());
      dog.makeSound(); // Polymorphism - calls Dog's overridden makeSound
  }
}