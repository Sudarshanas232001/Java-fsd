package com.learning.core.Phase1Assignment2;

//Write a program in Java to create a thread by extending the ‘Thread’ class and by implementing the “Runnable” interface

public class P01 extends Thread {
  public void run() {
      // Code to be executed by the thread
      for (int i = 0; i < 5; i++) {
          System.out.println("Thread: " + i);
         try {
             Thread.sleep(1000);

         }
         catch (InterruptedException e){
              e.printStackTrace();
         }
      }
  }

  public static void main(String[] args) {
      P01 thread = new P01();
      thread.start();
      for (int i =0 ; i< 11 ;i++)
      {
          System.out.println("Main: " + i);
          try {
              Thread.sleep(1000); // Pause for 1 second
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }
  }

}