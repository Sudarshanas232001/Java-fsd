package com.learning.core.Phase1Assignment2;

//Write a program in Java to resolve the diamond problem using OOPs’ concepts

interface InterfaceA {
  void doSomething();
}

//interface with the same method as InterfaceA
interface InterfaceB {
  void doSomething();
}

//Cimplementing both interfaces
class ConcreteClass implements InterfaceA, InterfaceB {
  // Overriding the doSomething method to resolve the diamond problem
  @Override
  public void doSomething() {
      System.out.println("Do something!");
  }
}

//Main class to demonstrate the resolution of the diamond problem
public class P09 {
  public static void main(String[] args) {
      ConcreteClass obj = new ConcreteClass();
      obj.doSomething(); 
  }
}