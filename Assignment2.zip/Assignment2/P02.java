package com.learning.core.Phase1Assignment2;

//Write a program in Java to demonstrate sleep() and wait()
public class P02 {

  private static Object lock = new Object();
  private static boolean flag = false;

  public static void main(String[] args) {
      Thread t1 = new Thread(new Worker());
      Thread t2 = new Thread(new WraitingThread());
      t1.start();
      t2.start();

  }

  static class Worker implements Runnable {

      public void run() {
          try {
              Thread.sleep(3000);
              System.out.println("Worker has finished work.");
              synchronized (lock) {
                  flag = true;
                  lock.notifyAll();
              }
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }


  }

  static class WraitingThread implements Runnable {
      public void run() {
          try {
              synchronized (lock) {
                  while (!flag) {
                      System.out.println("Waiting for worker to finish...");
                      lock.wait();
                  }
                  System.out.println("Worker has finished. Continuing execution...");
              }
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }
  }
}