package com.learning.core.Phase1Assignment2;

public class P04 {
    public static double divideNum(double dividend, double divisor) {
        return dividend / divisor;
    }

    public static void main(String[] args) {
        try {
        	double result = divideNum(20, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Finally block executed.");
        }
    }
}