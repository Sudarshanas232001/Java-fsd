package com.learning.core.Phase1Assignment2;

//Writing a program in Java to create, read, update, and delete operations on the files in Java.
import java.io.*;
import java.util.Scanner;

public class P07 {
  public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String fileName = "example.txt";

      while (true) {
          System.out.println("Select an operation:");
          System.out.println("1. Create a file");
          System.out.println("2. Read from a file");
          System.out.println("3. Update a file");
          System.out.println("4. Delete a file");
          System.out.println("5. Exit");

          int choice = scanner.nextInt();
          scanner.nextLine(); // Consume the newline character

          switch (choice) {
              case 1:
                  createFile(fileName);
                  break;
              case 2:
                  readFile(fileName);
                  break;
              case 3:
                  updateFile(fileName);
                  break;
              case 4:
                  deleteFile(fileName);
                  break;
              case 5:
                  System.exit(0);
              default:
                  System.out.println("Invalid choice. Please try again.");
          }
      }
  }

  private static void createFile(String fileName) {
      try {
          File file = new File(fileName);
          if (file.createNewFile()) {
              System.out.println("File created: " + file.getName());
          } else {
              System.out.println("File already exists.");
          }
      } catch (IOException e) {
          System.out.println("An error occurred while creating the file.");
          e.printStackTrace();
      }
  }

  private static void readFile(String fileName) {
      try {
          File file = new File(fileName);
          Scanner scanner = new Scanner(file);
          while (scanner.hasNextLine()) {
              String line = scanner.nextLine();
              System.out.println(line);
          }
          scanner.close();
      } catch (FileNotFoundException e) {
          System.out.println("File not found.");
          e.printStackTrace();
      }
  }

  private static void updateFile(String fileName) {
      try {
          FileWriter writer = new FileWriter(fileName, true);
          BufferedWriter bufferedWriter = new BufferedWriter(writer);
          Scanner scanner = new Scanner(System.in);
          System.out.println("Enter the content to append to the file:");
          String content = scanner.nextLine();
          bufferedWriter.write(content);
          bufferedWriter.newLine();
          bufferedWriter.close();
          System.out.println("File updated successfully.");
      } catch (IOException e) {
          System.out.println("An error occurred while updating the file.");
          e.printStackTrace();
      }
  }

  private static void deleteFile(String fileName) {
      File file = new File(fileName);
      if (file.delete()) {
          System.out.println("File deleted: " + file.getName());
      } else {
          System.out.println("Failed to delete the file.");
      }
  }
}