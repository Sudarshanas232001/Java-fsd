package com.learning.core.Phase1Assignment2;

//Write a program in Java to demonstrate exception handling

public class P06 {
  public static double divide(double numerator, double denominator) {
      return numerator / denominator;
  }
  public static void main(String[] args) {
      try {
    	  double result = divide(20, 0);
          System.out.println("The result is: " + result);
      } catch (ArithmeticException e) {

          System.out.println("An arithmetic error occurred: " + e.getMessage());
      } finally {

          System.out.println("The 'try catch' block is finished.");
      }

  }
}