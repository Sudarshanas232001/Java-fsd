package com.learning.core.Phase1Assignment2;

public class CustomException extends Exception{
    public CustomException(String message) {
        super(message);
    }
}