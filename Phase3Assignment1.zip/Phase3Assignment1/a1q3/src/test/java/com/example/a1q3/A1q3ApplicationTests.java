package com.example.a1q3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1q3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
