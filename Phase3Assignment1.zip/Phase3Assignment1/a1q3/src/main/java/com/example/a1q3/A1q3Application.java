package com.example.a1q3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A1q3Application {

	public static void main(String[] args) {
		SpringApplication.run(A1q3Application.class, args);
	}

}
