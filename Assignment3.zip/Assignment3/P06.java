package com.learning.core.Phase1Assignment3;

class Node1 {
    int data;
    Node next;

    public Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    public CircularLinkedList() {
        this.head = null;
    }

    // Method to insert a new element into a sorted circular linked list
    public void insertSorted(int data) {
        Node newNode = new Node(data);
        Node current = head;

        // If the list is empty, insert the new node as the head
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (data <= head.data) {
            // If the new data is smaller than or equal to the head's data, insert before the head
            newNode.next = head;
            Node last = getLastNode();
            head = newNode;
            last.next = head;
        } else {
            // Find the correct position to insert the new node
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Helper method to get the last node of the circular linked list
    private Node getLastNode() {
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }

    // Method to display the elements of the circular linked list
    public void display() {
        Node current = head;
        if (head != null) {
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
            System.out.println();
        }
    }
}

public class P06 {
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        list.insertSorted(5);
        list.insertSorted(10);
        list.insertSorted(15);
        list.insertSorted(20);
        
        System.out.println("Original Sorted Circular Linked List:");
        list.display();

        // Insert a new element into the sorted circular linked list
        int newData = 12;
        list.insertSorted(newData);

        System.out.println("\nUpdated Sorted Circular Linked List:");
        list.display();
    }
}
