package com.learning.core.Phase1Assignment3;

import java.util.LinkedList;
import java.util.Queue;

public class P09 {
    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);

        // Display the queue
        System.out.println("Queue after insertion: " + queue);

        // Remove an element from the queue
        int removedElement = queue.remove();
        System.out.println("Removed element: " + removedElement);
        
        // Display the queue after removal
        System.out.println("Queue after removal: " + queue);
        
        queue.add(40);
        
        // Display the queue
        System.out.println("Queue after insertion: " + queue);
        
        // Remove an element from the queue
        int removedElement2 = queue.remove();
        System.out.println("Removed element: " + removedElement2);
           
        // Display the queue after removal
        System.out.println("Queue after removal: " + queue);
        
        queue.add(50);
        
        // Display the queue
        System.out.println("Queue after insertion: " + queue);
    }
}
