package com.learning.core.Phase1Assignment3;

import java.util.Scanner;

public class P01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Input array elements
        int[] array = new int[size];
        System.out.println("Enter the array elements:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        // Right rotate the array by 5 steps
        int steps = 5; // Number of steps to rotate
        rightRotate(array, steps);

        // Print the rotated array
        System.out.println("Array after right rotation by 5 steps:");
        for (int num : array) {
            System.out.print(num + " ");
        }

        scanner.close();
    }

    public static void rightRotate(int[] arr, int steps) {
        int n = arr.length;
        steps %= n; // Adjust steps if greater than array length
        reverse(arr, 0, n - 1); // Reverse the whole array
        reverse(arr, 0, steps - 1); // Reverse the first 'steps' elements
        reverse(arr, steps, n - 1); // Reverse the remaining elements
    }

    public static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
}
