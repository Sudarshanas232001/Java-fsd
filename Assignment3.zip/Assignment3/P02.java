package com.learning.core.Phase1Assignment3;

import java.util.Arrays;
import java.util.Scanner;

public class P02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the size of the array
        System.out.print("Enter the size of the list: ");
        int size = scanner.nextInt();

        // Input the elements of the array
        System.out.println("Enter the elements of the list:");
        int[] list = new int[size];
        for (int i = 0; i < size; i++) {
            list[i] = scanner.nextInt();
        }

        // Sort the array
        Arrays.sort(list);

        // Find the fourth smallest element
        int fourthSmallest = list[3]; // Index 3 corresponds to the fourth smallest element

        // Output the result
        System.out.println("The fourth smallest element is: " + fourthSmallest);

        scanner.close();
    }
}
