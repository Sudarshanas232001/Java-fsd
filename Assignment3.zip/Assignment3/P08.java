package com.learning.core.Phase1Assignment3;

import java.util.Stack;

public class P08 {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Push elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        // Print the stack
        System.out.println("Stack: " + stack);
        
        // Print the size of the stack
        System.out.println("Stack Size: " + stack.size());
        
        // Peek at the top element of the stack
        int topElement = stack.peek();
        System.out.println("Top Element: " + topElement);

        // Pop an element from the stack
        int poppedElement = stack.pop();
        System.out.println("Popped Element: " + poppedElement);

        // Print the updated stack
        System.out.println("Stack after popping: " + stack);

        // Peek at the top element of the stack
        int topElement2 = stack.peek();
        System.out.println("Top Element: " + topElement2);

        // Print the size of the stack
        System.out.println("Stack Size: " + stack.size());
    }
}
